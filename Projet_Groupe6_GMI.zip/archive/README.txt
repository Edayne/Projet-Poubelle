Pour tester le fonctionnement du projet
Veuillez sous eclipse ouvrir le dossier .tar
Puis lancer le fichier Main.java pour tester les méthodes
Remarque : Pour tester la méthode renouveler, veuillez lorsque demander saisir une catégorie 
appartenant au catalogue donné dans Produit pour pouvoir saisir une offre convenable
Ex : Alimentaire






